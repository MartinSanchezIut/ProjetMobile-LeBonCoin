package com.example.projetmobile.BDD.Repository;

public class UserRepository {
}
