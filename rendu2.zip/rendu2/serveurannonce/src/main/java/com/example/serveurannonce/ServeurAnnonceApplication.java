package com.example.serveurannonce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServeurAnnonceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServeurAnnonceApplication.class, args);
    }

}
