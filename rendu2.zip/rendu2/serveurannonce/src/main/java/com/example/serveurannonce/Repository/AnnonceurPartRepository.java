package com.example.serveurannonce.Repository;

import com.example.serveurannonce.Models.Annonceur_Particulier;
import com.example.serveurannonce.Models.Annonceur_pro;

public interface AnnonceurPartRepository extends UserbaseRepository<Annonceur_Particulier>{
}
