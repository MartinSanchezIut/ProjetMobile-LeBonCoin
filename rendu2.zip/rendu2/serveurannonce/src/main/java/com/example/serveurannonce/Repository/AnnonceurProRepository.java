package com.example.serveurannonce.Repository;

import com.example.serveurannonce.Models.Annonceur_pro;

public interface AnnonceurProRepository extends UserbaseRepository<Annonceur_pro>{
}
