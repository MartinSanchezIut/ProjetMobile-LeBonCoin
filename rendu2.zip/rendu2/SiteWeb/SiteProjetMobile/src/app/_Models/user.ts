export interface User {
    id_user : number;
    pseudo : string;
    nom : string;
    prenom : string;
    email : string;
    numero : string;
    mot_de_passe : string;
    statu : string;
}