import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-annoncessauvegardees',
  templateUrl: './annoncessauvegardees.component.html',
  styleUrls: ['./annoncessauvegardees.component.css']
})
export class AnnoncessauvegardeesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
