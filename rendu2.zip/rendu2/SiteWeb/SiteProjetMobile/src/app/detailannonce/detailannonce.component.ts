import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailannonce',
  templateUrl: './detailannonce.component.html',
  styleUrls: ['./detailannonce.component.css']
})
export class DetailannonceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
