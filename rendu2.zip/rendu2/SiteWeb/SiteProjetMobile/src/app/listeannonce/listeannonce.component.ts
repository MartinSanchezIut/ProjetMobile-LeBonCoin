import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listeannonce',
  templateUrl: './listeannonce.component.html',
  styleUrls: ['./listeannonce.component.css']
})
export class ListeannonceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
