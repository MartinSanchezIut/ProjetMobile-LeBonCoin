import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editerannonce',
  templateUrl: './editerannonce.component.html',
  styleUrls: ['./editerannonce.component.css']
})
export class EditerannonceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
