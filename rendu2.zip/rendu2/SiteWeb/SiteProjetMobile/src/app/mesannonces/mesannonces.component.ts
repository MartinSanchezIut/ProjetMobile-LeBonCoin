import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mesannonces',
  templateUrl: './mesannonces.component.html',
  styleUrls: ['./mesannonces.component.css']
})
export class MesannoncesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
